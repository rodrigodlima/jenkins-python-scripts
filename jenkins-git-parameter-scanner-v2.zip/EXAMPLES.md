# Exemplos Práticos - Jenkins Parameter Scanner

Este documento contém exemplos práticos de uso dos scanners em diferentes cenários reais.

## 📋 Casos de Uso

### 1. Auditoria de Parâmetros ECR

**Cenário:** Você precisa migrar de um registry Docker para outro e quer saber onde o parâmetro `ECR_PATH` está sendo usado.

```bash
# Modo simples (usando o script auxiliar)
./run_scanner.sh unified ECR_PATH

# Modo direto
python3 unified_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username admin \
    --token abc123def456 \
    --repos-path ~/projetos \
    --parameter ECR_PATH \
    --output auditoria_ecr.txt
```

**Resultado esperado:**
- Lista de todos os jobs que usam ECR_PATH
- Repositórios com Jenkinsfiles que referenciam ECR_PATH
- Análise cruzada mostrando correspondências
- Recomendações de parametrização

---

### 2. Identificar Jobs sem Parametrização

**Cenário:** Você quer encontrar jobs que usam valores hardcoded que deveriam ser parâmetros.

```bash
# Busca por AWS_REGION
python3 jenkins_parameter_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username admin \
    --token abc123def456 \
    --parameter AWS_REGION

# Analise o JSON gerado
cat jenkins_scan_results.json | jq '.[] | select(.found_in_script == true and .found_in_parameters == false)'
```

**O que procurar:**
- `found_in_script: true` + `found_in_parameters: false` = valor hardcoded
- Esses jobs são candidatos a refatoração

---

### 3. Validar Migração de Jenkinsfiles

**Cenário:** Você moveu Jenkinsfiles de jobs para repositórios Git e quer validar que tudo foi migrado.

**Passo 1:** Scan antes da migração
```bash
python3 jenkins_parameter_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username admin \
    --token abc123def456 \
    --parameter IMAGE_TAG \
    --output antes_migracao.txt
```

**Passo 2:** Scan depois da migração
```bash
python3 git_repository_scanner.py \
    --repos-path ~/projetos \
    --parameter IMAGE_TAG \
    --output depois_migracao.txt
```

**Passo 3:** Compare
```bash
# Conte as ocorrências
ANTES=$(grep -c "Job:" antes_migracao.txt)
DEPOIS=$(grep -c "Repositório:" depois_migracao.txt)

echo "Jobs antes: $ANTES"
echo "Repos depois: $DEPOIS"

if [ "$ANTES" -eq "$DEPOIS" ]; then
    echo "✓ Migração completa!"
else
    echo "⚠ Verifique se todos os jobs foram migrados"
fi
```

---

### 4. Buscar Múltiplos Parâmetros de Uma Vez

**Cenário:** Você está fazendo uma auditoria completa de variáveis de ambiente.

```bash
#!/bin/bash

# Lista de parâmetros a auditar
PARAMS=(
    "ECR_PATH"
    "AWS_REGION"
    "DOCKER_REGISTRY"
    "IMAGE_TAG"
    "ENVIRONMENT"
    "DB_HOST"
    "KUBERNETES_NAMESPACE"
)

# Cria diretório para relatórios
mkdir -p auditoria_$(date +%Y%m%d)

# Busca cada parâmetro
for PARAM in "${PARAMS[@]}"; do
    echo "Buscando: $PARAM"
    
    python3 unified_scanner.py \
        --jenkins-url https://jenkins.empresa.com \
        --username admin \
        --token abc123def456 \
        --repos-path ~/projetos \
        --parameter "$PARAM" \
        --output "auditoria_$(date +%Y%m%d)/report_${PARAM}.txt"
    
    echo "---"
done

# Gera resumo consolidado
echo "Resumo da Auditoria" > auditoria_$(date +%Y%m%d)/RESUMO.txt
echo "===================" >> auditoria_$(date +%Y%m%d)/RESUMO.txt
echo "" >> auditoria_$(date +%Y%m%d)/RESUMO.txt

for PARAM in "${PARAMS[@]}"; do
    JENKINS_COUNT=$(grep -c "Job:" "auditoria_$(date +%Y%m%d)/report_${PARAM}.txt" 2>/dev/null || echo "0")
    GIT_COUNT=$(grep -c "Repositório:" "auditoria_$(date +%Y%m%d)/report_${PARAM}.txt" 2>/dev/null || echo "0")
    
    echo "$PARAM: $JENKINS_COUNT jobs, $GIT_COUNT repos" >> auditoria_$(date +%Y%m%d)/RESUMO.txt
done

echo "✓ Auditoria completa! Veja: auditoria_$(date +%Y%m%d)/"
```

---

### 5. Análise de Repositórios Órfãos

**Cenário:** Você quer encontrar repositórios que têm Jenkinsfiles mas não têm jobs correspondentes no Jenkins.

```bash
# Passo 1: Scan Git
python3 git_repository_scanner.py \
    --repos-path ~/projetos \
    --parameter "parameters" \
    --output repos_com_jenkinsfile.txt

# Passo 2: Scan Jenkins
python3 jenkins_parameter_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username admin \
    --token abc123def456 \
    --parameter "parameters" \
    --output jobs_jenkins.txt

# Passo 3: Use o scanner unificado para análise cruzada
python3 unified_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username admin \
    --token abc123def456 \
    --repos-path ~/projetos \
    --parameter "parameters" \
    --output analise_cruzada.txt

# A seção "Repositórios com parâmetro mas sem job Jenkins correspondente" 
# mostrará os órfãos
```

---

### 6. Integração com Pipeline de CI/CD

**Cenário:** Você quer executar o scan automaticamente a cada merge na branch main.

**Jenkinsfile:**
```groovy
pipeline {
    agent any
    
    parameters {
        string(name: 'PARAMETER_TO_SEARCH', defaultValue: 'ECR_PATH', description: 'Parâmetro a buscar')
    }
    
    stages {
        stage('Setup') {
            steps {
                // Clone dos repositórios
                sh '''
                    mkdir -p repos
                    cd repos
                    # Clone aqui seus repos ou use workspace existente
                '''
            }
        }
        
        stage('Parameter Audit') {
            steps {
                script {
                    withCredentials([string(credentialsId: 'jenkins-api-token', variable: 'TOKEN')]) {
                        sh """
                            python3 unified_scanner.py \\
                                --jenkins-url ${JENKINS_URL} \\
                                --username ${JENKINS_USER} \\
                                --token ${TOKEN} \\
                                --repos-path ./repos \\
                                --parameter ${params.PARAMETER_TO_SEARCH} \\
                                --output audit_report.txt
                        """
                    }
                }
            }
        }
        
        stage('Analyze Results') {
            steps {
                script {
                    def jsonReport = readJSON file: 'unified_scan_results.json'
                    
                    def jenkinsCount = jsonReport.jenkins_results.size()
                    def gitCount = jsonReport.git_results.size()
                    
                    echo "Jobs encontrados: ${jenkinsCount}"
                    echo "Repositórios encontrados: ${gitCount}"
                    
                    // Verifica se há inconsistências
                    def issues = jsonReport.jenkins_results.findAll { 
                        it.found_in_script && !it.found_in_parameters 
                    }
                    
                    if (issues.size() > 0) {
                        unstable("Encontrados ${issues.size()} jobs com valores não parametrizados")
                    }
                }
            }
        }
        
        stage('Archive') {
            steps {
                archiveArtifacts artifacts: '*.txt,*.json', allowEmptyArchive: false
                
                // Publica relatório
                publishHTML([
                    allowMissing: false,
                    alwaysLinkToLastBuild: true,
                    keepAll: true,
                    reportDir: '.',
                    reportFiles: 'audit_report.txt',
                    reportName: 'Parameter Audit Report'
                ])
            }
        }
    }
    
    post {
        always {
            // Limpa workspace
            cleanWs()
        }
        success {
            echo '✓ Auditoria concluída com sucesso!'
        }
        unstable {
            emailext(
                subject: "⚠ Auditoria de Parâmetros - Issues Encontrados",
                body: """
                    Foram encontrados jobs com parâmetros não declarados.
                    
                    Veja o relatório completo em: ${BUILD_URL}
                """,
                to: 'devops@empresa.com'
            )
        }
    }
}
```

---

### 7. Comparação Entre Ambientes

**Cenário:** Você tem Jenkins de DEV e PROD e quer comparar se os mesmos parâmetros estão configurados.

```bash
#!/bin/bash

PARAM="ECR_PATH"

# Scan no Jenkins DEV
python3 jenkins_parameter_scanner.py \
    --jenkins-url https://jenkins-dev.empresa.com \
    --username admin \
    --token token_dev \
    --parameter "$PARAM" \
    --output dev_report.txt

# Scan no Jenkins PROD
python3 jenkins_parameter_scanner.py \
    --jenkins-url https://jenkins-prod.empresa.com \
    --username admin \
    --token token_prod \
    --parameter "$PARAM" \
    --output prod_report.txt

# Extrai lista de jobs
grep "Job:" dev_report.txt | awk '{print $2}' | sort > dev_jobs.txt
grep "Job:" prod_report.txt | awk '{print $2}' | sort > prod_jobs.txt

# Compara
echo "Jobs apenas em DEV:"
comm -23 dev_jobs.txt prod_jobs.txt

echo ""
echo "Jobs apenas em PROD:"
comm -13 dev_jobs.txt prod_jobs.txt

echo ""
echo "Jobs em ambos:"
comm -12 dev_jobs.txt prod_jobs.txt
```

---

### 8. Geração de Relatório Executivo

**Cenário:** Você precisa apresentar um relatório para gestão sobre uso de parâmetros.

```bash
#!/bin/bash

# Script para gerar relatório executivo
OUTPUT_DIR="relatorio_executivo_$(date +%Y%m%d)"
mkdir -p "$OUTPUT_DIR"

# Lista de parâmetros críticos
CRITICAL_PARAMS=("ECR_PATH" "DB_PASSWORD" "API_KEY" "AWS_ACCESS_KEY")

echo "Gerando relatório executivo..." > "$OUTPUT_DIR/relatorio.md"
echo "==============================" >> "$OUTPUT_DIR/relatorio.md"
echo "" >> "$OUTPUT_DIR/relatorio.md"
echo "Data: $(date)" >> "$OUTPUT_DIR/relatorio.md"
echo "" >> "$OUTPUT_DIR/relatorio.md"

for PARAM in "${CRITICAL_PARAMS[@]}"; do
    echo "## $PARAM" >> "$OUTPUT_DIR/relatorio.md"
    echo "" >> "$OUTPUT_DIR/relatorio.md"
    
    # Executa scan
    python3 unified_scanner.py \
        --jenkins-url https://jenkins.empresa.com \
        --username admin \
        --token abc123 \
        --repos-path ~/projetos \
        --parameter "$PARAM" \
        --output "$OUTPUT_DIR/raw_${PARAM}.txt" 2>&1 | tee -a "$OUTPUT_DIR/log.txt"
    
    # Extrai métricas
    JENKINS_JOBS=$(grep -c "Job:" "$OUTPUT_DIR/raw_${PARAM}.txt" 2>/dev/null || echo "0")
    GIT_REPOS=$(grep -c "Repositório:" "$OUTPUT_DIR/raw_${PARAM}.txt" 2>/dev/null || echo "0")
    
    echo "- **Jobs Jenkins:** $JENKINS_JOBS" >> "$OUTPUT_DIR/relatorio.md"
    echo "- **Repositórios Git:** $GIT_REPOS" >> "$OUTPUT_DIR/relatorio.md"
    
    # Análise de segurança para parâmetros sensíveis
    if [[ "$PARAM" == *"PASSWORD"* ]] || [[ "$PARAM" == *"KEY"* ]] || [[ "$PARAM" == *"SECRET"* ]]; then
        echo "- **⚠️ PARÂMETRO SENSÍVEL**" >> "$OUTPUT_DIR/relatorio.md"
        echo "  - Recomenda-se uso de credentials do Jenkins" >> "$OUTPUT_DIR/relatorio.md"
    fi
    
    echo "" >> "$OUTPUT_DIR/relatorio.md"
done

# Converte para HTML (se pandoc estiver disponível)
if command -v pandoc &> /dev/null; then
    pandoc "$OUTPUT_DIR/relatorio.md" -o "$OUTPUT_DIR/relatorio.html" --standalone --toc
    echo "✓ Relatório HTML gerado: $OUTPUT_DIR/relatorio.html"
fi

echo "✓ Relatório completo em: $OUTPUT_DIR/"
```

---

### 9. Monitoramento de Drift

**Cenário:** Você quer detectar quando parâmetros são adicionados/removidos ao longo do tempo.

```bash
#!/bin/bash

BASELINE_DIR="baseline"
CURRENT_DIR="scan_$(date +%Y%m%d)"

# Primeira execução - cria baseline
if [ ! -d "$BASELINE_DIR" ]; then
    echo "Criando baseline..."
    mkdir -p "$BASELINE_DIR"
    
    python3 unified_scanner.py \
        --jenkins-url https://jenkins.empresa.com \
        --username admin \
        --token abc123 \
        --repos-path ~/projetos \
        --parameter ".*" \
        --output "$BASELINE_DIR/baseline.txt"
    
    cp unified_scan_results.json "$BASELINE_DIR/"
    echo "✓ Baseline criada"
    exit 0
fi

# Scans subsequentes - detecta drift
echo "Detectando mudanças desde baseline..."
mkdir -p "$CURRENT_DIR"

python3 unified_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username admin \
    --token abc123 \
    --repos-path ~/projetos \
    --parameter ".*" \
    --output "$CURRENT_DIR/current.txt"

cp unified_scan_results.json "$CURRENT_DIR/"

# Compara JSONs
python3 << 'EOF'
import json
import sys

with open('baseline/unified_scan_results.json') as f:
    baseline = json.load(f)

with open('$CURRENT_DIR/unified_scan_results.json') as f:
    current = json.load(f)

baseline_jobs = {j['job_name'] for j in baseline['jenkins_results']}
current_jobs = {j['job_name'] for j in current['jenkins_results']}

added = current_jobs - baseline_jobs
removed = baseline_jobs - current_jobs

print("=" * 80)
print("DRIFT REPORT")
print("=" * 80)
print(f"\nJobs adicionados: {len(added)}")
for job in sorted(added):
    print(f"  + {job}")

print(f"\nJobs removidos: {len(removed)}")
for job in sorted(removed):
    print(f"  - {job}")

if added or removed:
    sys.exit(1)
else:
    print("\n✓ Nenhuma mudança detectada")
    sys.exit(0)
EOF

DRIFT=$?

if [ $DRIFT -ne 0 ]; then
    echo ""
    echo "⚠️ DRIFT DETECTADO!"
    echo "Revisar mudanças em: $CURRENT_DIR"
    
    # Opcional: enviar alerta
    # mail -s "Alert: Drift Detectado" devops@empresa.com < drift_report.txt
fi
```

---

## 🔧 Dicas e Truques

### Busca com Regex

Para buscar padrões mais complexos, você pode modificar o script:

```python
# Em jenkins_parameter_scanner.py, linha ~80
# Substitua a busca simples por regex
import re

pattern = re.compile(r'ECR_PATH|DOCKER_.*|.*_REGISTRY')
if pattern.search(config_xml):
    # ... código de processamento
```

### Cache de Resultados

Para evitar re-scan:

```bash
# Use cache
if [ -f "cache_$(date +%Y%m%d).json" ]; then
    echo "Usando cache de hoje"
    cp "cache_$(date +%Y%m%d).json" unified_scan_results.json
else
    # Executa scan normal
    python3 unified_scanner.py ...
    cp unified_scan_results.json "cache_$(date +%Y%m%d).json"
fi
```

### Filtros Avançados com jq

```bash
# Jobs que usam o parâmetro mas não definem
cat unified_scan_results.json | jq '.jenkins_results[] | select(.found_in_script == true and .found_in_parameters == false) | .job_name'

# Repositórios com mais de 5 ocorrências
cat unified_scan_results.json | jq '.git_results[] | select((.matches | length) > 5)'

# Contagem por tipo de parâmetro
cat jenkins_scan_results.json | jq '.[] | .parameter_type' | sort | uniq -c
```

---

## 📊 Interpretando Resultados

### O que significa cada campo:

- **found_in_parameters**: Parâmetro está definido no job
- **found_in_script**: Parâmetro é usado no script/Jenkinsfile
- **parameter_type**: Tipo do parâmetro (String, Boolean, etc.)
- **script_matches**: Trechos onde o parâmetro é usado

### Cenários comuns:

1. **found_in_parameters=true, found_in_script=true**: ✅ Uso correto
2. **found_in_parameters=true, found_in_script=false**: ⚠️ Parâmetro definido mas não usado
3. **found_in_parameters=false, found_in_script=true**: ⚠️ Valor hardcoded, deveria ser parâmetro
4. **found_in_parameters=false, found_in_script=false**: ❌ Não encontrado

---

Este documento é um guia vivo e deve ser atualizado conforme novos casos de uso surgem!
