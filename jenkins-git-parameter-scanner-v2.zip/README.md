# Jenkins & Git Parameter Scanner

🔍 Suite de ferramentas para buscar e analisar parâmetros em jobs do Jenkins e Jenkinsfiles nos repositórios Git.

## 📋 Índice

- [Funcionalidades](#funcionalidades)
- [Requisitos](#requisitos)
- [Instalação](#instalação)
- [Configuração](#configuração)
- [Uso](#uso)
- [Exemplos](#exemplos)
- [Saída](#saída)
- [Troubleshooting](#troubleshooting)

## 🎯 Funcionalidades

### Scanner do Jenkins (`jenkins_parameter_scanner.py`)
- ✅ Busca em todos os jobs do Jenkins recursivamente (incluindo pastas)
- ✅ Identifica parâmetros definidos nos jobs
- ✅ Detecta uso de parâmetros nos scripts/Jenkinsfiles
- ✅ Diferencia entre parâmetros declarados e apenas usados
- ✅ Extrai tipo de parâmetro (String, Boolean, Choice, etc.)
- ✅ Mostra contexto de uso

### Scanner Git (`git_repository_scanner.py`)
- ✅ Busca em todos os repositórios Git de um diretório
- ✅ Usa `git grep` para busca eficiente
- ✅ Analisa Jenkinsfiles e arquivos Groovy
- ✅ Detecta blocos `parameters` e `properties`
- ✅ Lista todos os parâmetros definidos em cada arquivo
- ✅ Mostra linha e contexto de cada ocorrência

### Scanner Unificado (`unified_scanner.py`)
- ✅ Combina resultados de Jenkins e Git
- ✅ Análise cruzada entre jobs e repositórios
- ✅ Identifica inconsistências
- ✅ Gera recomendações
- ✅ Relatório consolidado

## 📦 Requisitos

### Software
- Python 3.7+
- Git
- Acesso ao Jenkins (usuário + API token)
- Acesso aos repositórios Git (clonados localmente)

### Bibliotecas Python
```bash
pip install requests
```

## 🚀 Instalação

1. **Clone ou baixe os scripts:**
```bash
# Os arquivos principais são:
# - jenkins_parameter_scanner.py
# - git_repository_scanner.py
# - unified_scanner.py
# - config.ini.example
```

2. **Dê permissão de execução:**
```bash
chmod +x jenkins_parameter_scanner.py
chmod +x git_repository_scanner.py
chmod +x unified_scanner.py
```

3. **Instale as dependências:**
```bash
pip install requests
```

## ⚙️ Configuração

### 1. Gerar Token do Jenkins

1. Acesse o Jenkins
2. Clique no seu nome de usuário (canto superior direito)
3. Clique em "Configure"
4. Na seção "API Token", clique em "Add new Token"
5. Dê um nome (ex: "scanner") e clique em "Generate"
6. **Copie o token gerado** (não será mostrado novamente!)

### 2. Preparar os Repositórios Git

Clone todos os repositórios que deseja escanear em um diretório:

```bash
mkdir ~/meus-repos
cd ~/meus-repos

git clone https://git.empresa.com/projeto1.git
git clone https://git.empresa.com/projeto2.git
git clone https://git.empresa.com/projeto3.git
# ... etc
```

### 3. Configurar Credenciais (Opcional)

Copie o arquivo de exemplo:
```bash
cp config.ini.example config.ini
```

Edite o `config.ini` com suas credenciais:
```ini
[jenkins]
url = https://jenkins.sua-empresa.com
username = seu_usuario
token = seu_token_real_aqui

[git]
repos_path = /home/usuario/meus-repos

[search]
default_parameter = ECR_PATH
```

## 💻 Uso

### Opção 1: Scanner Unificado (Recomendado)

Busca completa em Jenkins + Git:

```bash
python unified_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username seu_usuario \
    --token seu_token \
    --repos-path ~/meus-repos \
    --parameter ECR_PATH \
    --output relatorio_completo.txt
```

### Opção 2: Apenas Jenkins

```bash
python jenkins_parameter_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username seu_usuario \
    --token seu_token \
    --parameter ECR_PATH \
    --output relatorio_jenkins.txt
```

### Opção 3: Apenas Repositórios Git

```bash
python git_repository_scanner.py \
    --repos-path ~/meus-repos \
    --parameter ECR_PATH \
    --output relatorio_git.txt
```

## 📝 Exemplos

### Exemplo 1: Buscar parâmetro específico

```bash
# Busca por ECR_PATH
python unified_scanner.py \
    --jenkins-url https://jenkins.empresa.com \
    --username joao.silva \
    --token 11a1b2c3d4e5f6g7h8i9j0 \
    --repos-path /home/joao/projetos \
    --parameter ECR_PATH
```

### Exemplo 2: Buscar múltiplos parâmetros

Crie um script bash para buscar vários parâmetros:

```bash
#!/bin/bash

PARAMETERS=("ECR_PATH" "AWS_REGION" "DOCKER_REGISTRY" "IMAGE_TAG")

for param in "${PARAMETERS[@]}"; do
    echo "Buscando: $param"
    python unified_scanner.py \
        --jenkins-url https://jenkins.empresa.com \
        --username seu_usuario \
        --token seu_token \
        --repos-path ~/repos \
        --parameter "$param" \
        --output "report_${param}.txt"
done
```

### Exemplo 3: Buscar apenas em jobs específicos

Modifique o script `jenkins_parameter_scanner.py` para filtrar:

```python
# Adicione no método get_all_jobs, após obter a lista
jobs = [j for j in jobs if 'microservice' in j['name'].lower()]
```

## 📊 Saída

Os scripts geram dois tipos de arquivo:

### 1. Relatório em Texto (.txt)

Formato legível com:
- Resumo executivo
- Lista de jobs/repositórios encontrados
- Contexto de uso
- Recomendações

Exemplo:
```
================================================================================
RELATÓRIO CONSOLIDADO: 'ECR_PATH'
================================================================================

📊 RESUMO EXECUTIVO
--------------------------------------------------------------------------------
Parâmetro buscado: ECR_PATH
Jobs Jenkins encontrados: 5
Repositórios Git encontrados: 3

Detalhamento Jenkins:
  - Com parâmetro definido: 3
  - Usado apenas no script: 2

Detalhamento Git:
  - Total de arquivos com ocorrências: 7

🔍 ANÁLISE CRUZADA
--------------------------------------------------------------------------------
✓ Job 'microservice-api' tem correspondência com repo(s): microservice-api
⚠ Job 'legacy-batch' sem correspondência clara nos repositórios escaneados
...
```

### 2. JSON Detalhado (.json)

Formato estruturado para processamento automatizado:

```json
{
  "parameter_name": "ECR_PATH",
  "jenkins_results": [
    {
      "job_name": "microservice-api",
      "job_url": "https://jenkins.empresa.com/job/microservice-api/",
      "found_in_parameters": true,
      "found_in_script": true,
      "parameter_type": "hudson.model.StringParameterDefinition",
      "script_matches": [
        "...docker push ${ECR_PATH}:${IMAGE_TAG}..."
      ]
    }
  ],
  "git_results": [
    {
      "repo_name": "microservice-api",
      "repo_path": "/home/user/repos/microservice-api",
      "matches": [
        {
          "file": "Jenkinsfile",
          "line": "25",
          "content": "string(name: 'ECR_PATH', defaultValue: '123456.dkr.ecr...')",
          "analysis": {
            "has_parameters_block": true,
            "parameter_definitions": ["ECR_PATH", "AWS_REGION"]
          }
        }
      ]
    }
  ]
}
```

## 🔧 Troubleshooting

### Erro: "Connection refused"

**Problema:** Não consegue conectar ao Jenkins

**Solução:**
1. Verifique se a URL está correta (sem barra no final)
2. Teste o acesso no navegador
3. Verifique firewall/VPN

### Erro: "401 Unauthorized"

**Problema:** Credenciais inválidas

**Solução:**
1. Verifique o usuário e token
2. Gere um novo token no Jenkins
3. Verifique se o usuário tem permissão de leitura

### Erro: "SSL Certificate verification failed"

**Problema:** Certificado SSL não confiável

**Solução temporária:**
```python
# No início do script, adicione:
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# E modifique as chamadas requests para:
response = self.session.get(url, verify=False)
```

**⚠️ ATENÇÃO:** Use apenas em ambientes de desenvolvimento/teste!

### Erro: "git: command not found"

**Problema:** Git não está instalado

**Solução:**
```bash
# Ubuntu/Debian
sudo apt-get install git

# CentOS/RHEL
sudo yum install git

# MacOS
brew install git
```

### Scanner muito lento

**Problema:** Muitos repositórios ou jobs

**Soluções:**
1. **Filtre repositórios:**
   ```bash
   # Crie subdiretórios com apenas os repos relevantes
   mkdir ~/repos-microservices
   # Clone apenas os necessários
   ```

2. **Execute em paralelo:**
   ```bash
   # Separe a busca em Jenkins e Git
   python jenkins_parameter_scanner.py ... &
   python git_repository_scanner.py ... &
   wait
   ```

3. **Use cache de repositórios:**
   ```python
   # Modifique para não clonar novamente
   # Se já tiver os repos clonados
   ```

### Não encontra nenhum resultado

**Verifique:**

1. **Nome do parâmetro está correto?**
   ```bash
   # Teste com busca case-insensitive
   grep -ri "ecr_path" ~/repos
   ```

2. **Repositórios estão clonados?**
   ```bash
   ls -la ~/repos/*/.git
   ```

3. **Usuário tem permissão nos jobs?**
   - Acesse o Jenkins manualmente
   - Verifique se vê todos os jobs

## 📈 Dicas Avançadas

### 1. Agendar Scan Periódico

Crie um cron job:

```bash
# Edite o crontab
crontab -e

# Adicione (executa toda segunda às 8h)
0 8 * * 1 /usr/bin/python3 /caminho/unified_scanner.py --jenkins-url ... --output /var/reports/scan_$(date +\%Y\%m\%d).txt
```

### 2. Enviar Relatório por Email

```bash
#!/bin/bash

OUTPUT="report_$(date +%Y%m%d).txt"

python unified_scanner.py \
    --jenkins-url ... \
    --parameter ECR_PATH \
    --output "$OUTPUT"

# Envia por email
mail -s "Relatório de Scan - ECR_PATH" -a "$OUTPUT" time@empresa.com < "$OUTPUT"
```

### 3. Integrar com CI/CD

```groovy
// Jenkinsfile
stage('Audit Parameters') {
    steps {
        sh '''
            python unified_scanner.py \
                --jenkins-url $JENKINS_URL \
                --username $JENKINS_USER \
                --token $JENKINS_TOKEN \
                --parameter ECR_PATH \
                --output audit_report.txt
        '''
        archiveArtifacts 'audit_report.*'
    }
}
```

## 📚 Referências

- [Jenkins API Documentation](https://www.jenkins.io/doc/book/using/remote-access-api/)
- [Git Grep Documentation](https://git-scm.com/docs/git-grep)
- [Pipeline Syntax Reference](https://www.jenkins.io/doc/book/pipeline/syntax/)

## 🤝 Contribuindo

Melhorias e sugestões são bem-vindas!

## 📄 Licença

Este projeto é fornecido "como está", sem garantias de qualquer tipo.

---

**Desenvolvido para facilitar auditorias e análises de parâmetros em pipelines Jenkins** 🚀
